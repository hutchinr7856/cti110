Python 3.11.1 (tags/v3.11.1:a7a450f, Dec  6 2022, 19:58:39) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

========== RESTART: E:/CTI 110 WEB DESIGN/P3HW1_Debugging_Hutchins.py ==========
Enter grade for Module 1: 86.5
Enter grade for Module 2: 80
Enter grade for Module 3: 76.9
Enter grade for Module 4: 90
Enter grade for Module 5: 79
Enter grade for Module6: 88
Traceback (most recent call last):
  File "E:/CTI 110 WEB DESIGN/P3HW1_Debugging_Hutchins.py", line 18, in <module>
    grades = [mod_1, mod2, mod_3, mod_4, mod_5, mod_6]
NameError: name 'mod2' is not defined. Did you mean: 'mod_2'?

========== RESTART: E:/CTI 110 WEB DESIGN/P3HW1_Debugging_Hutchins.py ==========
Enter grade for Module 1: 86.5
Enter grade for Module 2: 80
Enter grade for Module 3: 76.9
Enter grade for Module 4: 90
Enter grade for Module 5: 79
Enter grade for Module6: 
========== RESTART: E:/CTI 110 WEB DESIGN/P3HW1_Debugging_Hutchins.py ==========
Enter grade for Module 1: 86.5
Enter grade for Module 2: 80
Enter grade for Module 3: 76.9
Enter grade for Module 4: 90
Enter grade for Module 5: 79
Enter grade for Module 6: 88
Traceback (most recent call last):
  File "E:/CTI 110 WEB DESIGN/P3HW1_Debugging_Hutchins.py", line 24, in <module>
    total = sum(grades)
TypeError: unsupported operand type(s) for +: 'int' and 'str'

========== RESTART: E:/CTI 110 WEB DESIGN/P3HW1_Debugging_Hutchins.py ==========
Enter grade for Module 1: 86.5
Enter grade for Module 2: 80
Enter grade for Module 3: 76.9
Enter grade for Module 4: 90
Enter grade for Module 5: 79
Enter grade for Module 6: 88
Lowest Grade: 76.9
Highest Grade: 90.0
Sum of Grade: 500.4
Traceback (most recent call last):
  File "E:/CTI 110 WEB DESIGN/P3HW1_Debugging_Hutchins.py", line 31, in <module>
    print("Average:",avg)
NameError: name 'avg' is not defined
>>> 
========== RESTART: E:/CTI 110 WEB DESIGN/P3HW1_Debugging_Hutchins.py ==========
Enter grade for Module 1: 86.5
Enter grade for Module 2: 80
Enter grade for Module 3: 76.9
Enter grade for Module 4: 90
Enter grade for Module 5: 79
Enter grade for Module 6: 88
Lowest Grade: 76.9
Highest Grade: 90.0
Sum of Grade: 500.4
Average: 83.39999999999999
Your grade is: B
>>> 
========== RESTART: E:/CTI 110 WEB DESIGN/P3HW1_Debugging_Hutchins.py ==========
Enter grade for Module 1: 86.5
Enter grade for Module 2: 80
Enter grade for Module 3: 76.9
Enter grade for Module 4: 90
Enter grade for Module 5: 79
Enter grade for Module 6: 88
------------ Results ------------
Lowest Grade: 76.9
Highest Grade: 90.0
Sum of Grade: 500.4
Average: 83.39999999999999
--------------------------------------
Your grade is: B
>>> 
>>> 
>>> 
>>> 
